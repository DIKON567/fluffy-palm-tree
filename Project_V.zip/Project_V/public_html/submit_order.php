<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключение к БД
$host     = "localhost";
$username = "cg07421_projectv";
$password = "tatiannaluch";
$dbname   = "cg07421_projectv";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Создание таблицы orders (если нет)
$conn->query("
    CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        phone VARCHAR(50),
        email VARCHAR(100),
        product VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
");

// Создание таблицы subscribers (если нет)
$conn->query("
    CREATE TABLE IF NOT EXISTS subscribers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(100) UNIQUE
    )
");

// Получение данных из формы
$name    = $_POST['name']    ?? '';
$phone   = $_POST['phone']   ?? '';
$email   = $_POST['email']   ?? '';
$product = $_POST['product'] ?? '';

// Добавление в таблицу orders
$stmt = $conn->prepare("INSERT INTO orders (name, phone, email, product) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $phone, $email, $product);
$stmt->execute();
$stmt->close();

// Добавление email в subscribers (если ещё нет)
$stmt2 = $conn->prepare("INSERT IGNORE INTO subscribers (email) VALUES (?)");
$stmt2->bind_param("s", $email);
$stmt2->execute();
$stmt2->close();

$conn->close();

echo "Заявка успешно отправлена!";
?>
