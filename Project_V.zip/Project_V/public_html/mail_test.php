<?php
if (mail("sergionatali9@gmail.com", "Тест", "Письмо отправлено!")) {
    echo "✅ Письмо отправлено!";
} else {
    echo "❌ Не удалось отправить письмо.";
}
?>