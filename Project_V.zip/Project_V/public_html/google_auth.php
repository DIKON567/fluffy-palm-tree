<?php
require_once "vendor/autoload.php"; // Google Client lib

$client = new Google_Client(['client_id' => 'ВАШ_GOOGLE_CLIENT_ID']);
$payload = $client->verifyIdToken($_POST['credential']);

if ($payload) {
    $email = $payload['email'];
    $name = $payload['name'];

    $conn = new mysqli("localhost", "root", "", "user_system");

    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100),
        email VARCHAR(100) UNIQUE,
        password VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $stmt = $conn->prepare("INSERT IGNORE INTO users (username, email, password) VALUES (?, ?, '')");
    $stmt->bind_param("ss", $name, $email);
    $stmt->execute();

    echo "Вход через Google выполнен!";
} else {
    echo "Ошибка авторизации Google.";
}
