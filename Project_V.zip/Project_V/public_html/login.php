<?php
session_start();

$host     = "localhost";
$username = "cg07421_projectv";
$password = "tatiannaluch";
$dbname   = "cg07421_projectv";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    exit("Ошибка подключения к БД.");
}

$email = $_POST['email'] ?? '';
$pass  = $_POST['password'] ?? '';

$stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    exit("Пользователь не найден.");
}

$stmt->bind_result($id, $username, $hashed_password);
$stmt->fetch();

if (password_verify($pass, $hashed_password)) {
    $_SESSION['user_id'] = $id;
    $_SESSION['username'] = $username; // Сохраняем имя
    echo "✅ Добро пожаловать, $username!";
} else {
    echo "❌ Неверный пароль.";
}
