<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Подключение к БД
$host     = "localhost";
$username = "cg07421_projectv";
$password = "tatiannaluch";
$dbname   = "cg07421_projectv";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения к БД: " . $conn->connect_error);
}

// Обработка рассылки
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_mail'])) {
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $result = $conn->query("SELECT email FROM subscribers");
    while ($row = $result->fetch_assoc()) {
        mail($row['email'], $subject, $message);
    }
    $mail_status = "Рассылка завершена.";
}

// Обработка сохранения HTML из iframe
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_html']) && isset($_POST['filename'])) {
    $filename = basename($_POST['filename']);
    $html     = $_POST['html_data'];

    file_put_contents($filename, $html);
    $save_status = "Файл $filename сохранён.";
}

// Заявки
$orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <title>Админ-панель</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { font-family: sans-serif; padding: 20px; background: #f7f7f7; }
    h2 { margin-top: 40px; }
    form textarea, form input, select { width: 100%; padding: 10px; margin-top: 10px; margin-bottom: 15px; border-radius: 6px; border: 1px solid #ccc; }
    form button { padding: 10px 20px; background: #2196f3; color: white; border: none; border-radius: 6px; cursor: pointer; }
    table { width: 100%; border-collapse: collapse; background: white; margin-top: 20px; }
    th, td { border: 1px solid #ddd; padding: 10px; }
    th { background: #eee; }
    .status { background: #e8f5e9; padding: 10px; margin: 10px 0; border-left: 5px solid #4CAF50; }
    iframe { width: 100%; height: 500px; border: 1px solid #ccc; margin-bottom: 10px; }
  </style>
</head>
<body>

<h1>Админ-панель</h1>

<!-- Рассылка -->
<h2>Рассылка</h2>
<?php if (!empty($mail_status)) echo "<div class='status'>$mail_status</div>"; ?>
<form method="POST">
  <label>Тема письма</label>
  <input type="text" name="subject" required>

  <label>Сообщение</label>
  <textarea name="message" rows="4" required></textarea>

  <button type="submit" name="send_mail">Отправить</button>
</form>

<!-- Визуальный редактор -->
<h2>Редактирование страницы</h2>
<?php if (!empty($save_status)) echo "<div class='status'>$save_status</div>"; ?>
<form method="POST" id="editorForm">
  <label>Выберите HTML-файл:</label>
  <select name="filename" id="filename" onchange="loadFile()" required>
    <option value="">-- Выбрать --</option>
    <option value="index.html">index.html</option>
    <option value="Контакты.html">Контакты.html</option>
    <option value="История.html">История.html</option>
    <option value="О-нас.html">О-нас.html</option>
    <option value="Страница-2.html">Страница-2.html</option>
  </select>

  <br><br>
  <iframe id="editorFrame"></iframe>

  <input type="hidden" name="html_data" id="html_data">
  <button type="submit" name="save_html" onclick="saveContent()">Сохранить изменения</button>
</form>

<!-- Заявки -->
<h2>Заявки</h2>
<table>
  <tr><th>Имя</th><th>Телефон</th><th>Email</th><th>Товар</th><th>Дата</th></tr>
  <?php while ($row = $orders->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['phone']) ?></td>
      <td><?= htmlspecialchars($row['email']) ?></td>
      <td><?= htmlspecialchars($row['product']) ?></td>
      <td><?= $row['created_at'] ?></td>
    </tr>
  <?php endwhile; ?>
</table>

<script>
function loadFile() {
  const file = document.getElementById('filename').value;
  if (!file) return;

  fetch(file)
    .then(res => res.text())
    .then(html => {
      const iframe = document.getElementById('editorFrame');
      iframe.contentDocument.open();
      iframe.contentDocument.write(html);
      iframe.contentDocument.close();

      // Подключение CSS-файлов
      const head = iframe.contentDocument.head;
      const styles = [
        'nicepage.css', 'История.css', 'Контакты.css', 'Страница-2.css', 'О-нас.css', 'index.css'
      ];
      styles.forEach(css => {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = css;
        head.appendChild(link);
      });

      // Делаем контент редактируемым
      iframe.contentDocument.body.contentEditable = true;
    });
}

function saveContent() {
  const iframe = document.getElementById('editorFrame');
  const html = iframe.contentDocument.documentElement.outerHTML;
  document.getElementById('html_data').value = html;
}
</script>

</body>
</html>
