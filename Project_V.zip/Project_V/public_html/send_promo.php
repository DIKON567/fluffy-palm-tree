<?php
$conn = new mysqli("localhost", "root", "", "user_system");

$message = $_POST['message'];
$result = $conn->query("SELECT email FROM promo_emails");

while ($row = $result->fetch_assoc()) {
    mail($row['email'], "Акции от компании", $message);
}

echo "Рассылка завершена.";
?>
