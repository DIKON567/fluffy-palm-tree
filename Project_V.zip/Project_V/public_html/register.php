<?php
session_start();

$host     = "localhost";
$username = "cg07421_projectv";
$password = "tatiannaluch";
$dbname   = "cg07421_projectv";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    exit("Ошибка подключения к БД.");
}

$username = $_POST['username'] ?? '';
$email    = $_POST['email'] ?? '';
$pass     = $_POST['password'] ?? '';

$pass_hashed = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");

$stmt->bind_param("sss", $username, $email, $pass_hashed);

if ($stmt->execute()) {
    $_SESSION['user_id'] = $stmt->insert_id;
    $_SESSION['username'] = $username;
    echo "✅ Добро пожаловать, $username!";
} else {
    echo "❌ Пользователь уже существует.";
}
