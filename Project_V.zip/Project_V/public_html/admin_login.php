<?php
session_start();

$email = $_POST['email'];
$password = $_POST['password'];

$admin_email = "luchik.57@mail.ru";
$admin_password = "tatiannaluch";

if ($email === $admin_email && $password === $admin_password) {
    $_SESSION['admin'] = true;
    header("Location: admin_panel.php");
    exit;
} else {
    echo "Неверный логин или пароль.";
}
?>
