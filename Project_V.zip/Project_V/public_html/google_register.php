<?php
require_once "vendor/autoload.php"; // если используете Google Client Library

$client = new Google_Client(['client_id' => 'ВАШ_GOOGLE_CLIENT_ID']);
$payload = $client->verifyIdToken($_POST['credential']);

if ($payload) {
    $email = $payload['email'];
    $name = $payload['name'];

    $conn = new mysqli("localhost", "root", "", "user_system");
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }

    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100),
        email VARCHAR(100) UNIQUE,
        password VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $stmt = $conn->prepare("INSERT IGNORE INTO users (username, email, password) VALUES (?, ?, '')");
    $stmt->bind_param("ss", $name, $email);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo "Регистрация через Google успешна!";
} else {
    echo "Ошибка авторизации Google";
}
?>