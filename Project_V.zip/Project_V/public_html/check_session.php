<?php
session_start();

$response = [
    "logged_in" => false,
];

if (isset($_SESSION['user_id']) && isset($_SESSION['username'])) {
    $response["logged_in"] = true;
    $response["username"] = $_SESSION['username'];
}

header('Content-Type: application/json');
echo json_encode($response);
