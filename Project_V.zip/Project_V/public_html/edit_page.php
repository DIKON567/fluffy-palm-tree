<?php
session_start();
if (!isset($_SESSION['admin'])) exit("Доступ запрещён");

$file = basename($_GET['file']);
if (!file_exists($file)) exit("Файл не найден.");

$content = file_get_contents($file);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Редактирование: <?= htmlspecialchars($file) ?></title>
  <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
  <script>
    tinymce.init({
      selector: '#editor',
      height: 600,
      menubar: true,
      plugins: 'link image code table lists',
      toolbar: 'undo redo | formatselect | bold italic underline | alignleft aligncenter alignright | bullist numlist outdent indent | link image | code',
      language: 'ru'
    });
  </script>
</head>
<body>

<h2>Редактирование страницы: <?= htmlspecialchars($file) ?></h2>

<form method="POST">
  <textarea id="editor" name="content"><?= htmlspecialchars($content) ?></textarea><br>
  <button type="submit">💾 Сохранить</button>
</form>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    file_put_contents($file, $_POST['content']);
    echo "<p style='color:green;'>Сохранено!</p>";
}
?>

<p><a href="admin_panel.php">← Назад в панель</a></p>

</body>
</html>

